package com.example.lucy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_history.*
import kotlinx.android.synthetic.main.activity_main.*

class History : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        click_backH()
    }

    fun click_backH() //intent para cambio de ventanas
    {
        btnBackH.setOnClickListener()
        {
            val bHistory: Intent = Intent(getApplicationContext(), home::class.java)
            startActivity(bHistory)
        }
    }
}