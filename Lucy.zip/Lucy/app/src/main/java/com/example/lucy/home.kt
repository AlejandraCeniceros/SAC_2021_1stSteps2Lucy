package com.example.lucy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.activity_main.*

class home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        click_History()
    }

    fun click_History() //intent para cambio de ventanas
    {
        btnHistory.setOnClickListener()
        {
            val historyP: Intent = Intent(getApplicationContext(), History::class.java)
            startActivity(historyP)
        }
    }
}