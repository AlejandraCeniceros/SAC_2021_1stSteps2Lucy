package com.example.lucy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class NewsAct : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news)
    }
}