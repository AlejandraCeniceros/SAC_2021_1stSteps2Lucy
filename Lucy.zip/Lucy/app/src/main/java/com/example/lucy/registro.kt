package com.example.lucy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_log_in.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_registro.*

class registro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)
        click_back()
        click_SignUp()
    }

    fun click_back() //intent boton back
    {
        btnBack.setOnClickListener()
        {
            val main: Intent = Intent(getApplicationContext(), MainActivity::class.java)
            startActivity(main)
        }
    }
    fun click_SignUp() //intent boton back
    {
        btnSignUpf.setOnClickListener()
        {
            val home: Intent = Intent(getApplicationContext(), home::class.java)
            startActivity(home)
        }
    }
}