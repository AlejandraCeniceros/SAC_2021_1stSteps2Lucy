package com.example.lucy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_log_in.*
import kotlinx.android.synthetic.main.activity_main.*

class LogIn : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_in)
        click_Home()
        click_back()
    }

    fun click_Home() //intent para cambio de ventanas
    {
        btnsignin2.setOnClickListener()
        {
            val home: Intent = Intent(getApplicationContext(), home::class.java)
            startActivity(home)
        }
    }

    fun click_back() //intent boton back
    {
        btnback.setOnClickListener()
        {
            val main: Intent = Intent(getApplicationContext(), MainActivity::class.java)
            startActivity(main)
        }
    }

}