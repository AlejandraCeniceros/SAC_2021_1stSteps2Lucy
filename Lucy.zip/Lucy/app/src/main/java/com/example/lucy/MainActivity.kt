package com.example.lucy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.system.measureTimeMillis

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        Thread.sleep(3000)
        setTheme(R.style.SplashTheme)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        click_login()
        click_signup()
    }

    fun click_login() //intent para cambio de ventanas
    {
        BtnSignIn.setOnClickListener()
        {
            val login: Intent = Intent(getApplicationContext(), LogIn::class.java)
            startActivity(login)
        }
    }

    fun click_signup() //intent para cambio de ventanas
    {
        btnsignup.setOnClickListener()
        {
            val sup: Intent = Intent(getApplicationContext(), registro::class.java)
            startActivity(sup)
        }
    }


}